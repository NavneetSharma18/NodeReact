# nodeApp

After clone code run the command npm start

CREATE .ENV File after clone on your root directory after that add PORT=3000 in that file and save, so that file node server run on port 300
