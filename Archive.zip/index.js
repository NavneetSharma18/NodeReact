const express           = require('express');
const dotenv            = require('dotenv');
const flash             = require('connect-flash');
const {isAdmin,isUser,isGuest}  = require('./auth/auth.js');
const mongoose          = require('mongoose');
const passport          = require('passport');
const { check, validationResult } = require('express-validator');
const session           = require('express-session');
const bcrypt            = require('bcrypt');
const app               = express();
const expressLayouts    = require('express-ejs-layouts');



/*------------------------------------------
| Config the Env variables
--------------------------------------------*/

dotenv.config();
const PORT    = process.env.PORT;

/*------------------------------------------
| Config the Env variables
--------------------------------------------*/



require('./auth/passport')(passport);


mongoose.set("strictQuery", false);
app.use(express.urlencoded({extended: false}));
app.use(express.static('public'));


/*--------------------------------------------
| Setting of session 
---------------------------------------------*/

app.use(session({ cookie: { maxAge:  60 * 60 * 1000 }, 
                  secret: '@!@#$$$#@!@###$',
                  resave: false, 
                  saveUninitialized: false,
                  
                }));



app.use(flash());


/*--------------------------------------------
| Setting of global error message 
---------------------------------------------*/

app.use(function(req, res, next) {
  res.locals.success_msg = req.flash('success_msg');
  res.locals.error_msg   = req.flash('error_msg');
  res.locals.error       = req.flash('error');
  next();
});



/*------------------------------------------------
| Passport Js Authentication local-strategy Start
-------------------------------------------------*/ 

app.use(passport.initialize());
app.use(passport.session());


/*------------------------------------------
| Setting the View engine
--------------------------------------------*/

app.use(expressLayouts);
app.set('view engine', 'ejs');
app.set('layout', 'layouts/layout'); 


/*------------------------------------------
| Connecting to mongo DB
--------------------------------------------*/


mongoose
  .connect('mongodb+srv://root:root@cluster0.m7nltbc.mongodb.net/natours?retryWrites=true&w=majority', {
    useNewUrlParser: true,
    useUnifiedTopology: true
  })
  .then(() => {
    console.log("Successfully connect to MongoDB.");
    
  })
  .catch(err => {
    console.error("Connection error", err);
    process.exit();
  });


/*----------------------------------------------------------
|||||--------=> Setting the Routes <=------------------|||||||||
-----------------------------------------------------------*/

app.use('/', require('./routes/login'));
app.use('/user',isUser, require('./routes/user'));
app.use('/admin',isAdmin, require('./routes/admin'));



/*----------------------------------------------------------
| App listen
-----------------------------------------------------------*/

app.listen(PORT).on('error', function (err) {
        if(err.errno === 'EADDRINUSE') {
            console.log(`----- Port ${PORT} is busy, trying with port ${PORT + 1} -----`);
            listen(PORT + 1)
        } else {
            console.log(err);
        }
    });