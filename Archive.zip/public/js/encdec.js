
function encryptString(string_val){

	    var myPassword = "myPassword";
		var encrypted  = CryptoJS.AES.encrypt(string_val, myPassword);
		
	
}


