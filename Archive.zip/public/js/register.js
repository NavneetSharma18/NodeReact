$(document).ready(function(){


/*---------------------------------------------
| Check Payee Code Valid or Not
----------------------------------------------*/

	$("#payee_code_submit").click(function(){

	         if(!$("#payee_code").val()){
			    Swal.fire({
				  icon: 'error',
				  title: 'Oops...',
				  text: 'Payee code can`t be empty',
				  
				})
				return false;
	         }

	           const payee_code    = $("#payee_code").val();
	           let payee_code_en   = CryptoJS.AES.encrypt(payee_code, Skey);

			   $("#loading").show();
				$.ajax({
					
					 method  : "post",
					 url     : "/validatePayeeCode", 
					 data    : {"payee_code":''+payee_code_en+''} ,
					 dataType: "json",
                     success: function(res){

                     	$("#loading").hide();

                     	if(res.status == false){

                     		  Swal.fire({
								  icon: 'error',
								  title: 'Oops...',
								  text: res.message,
								  
								}).then(function() {
								    location.reload();
								})
								return false;

                     	}else{

                     		     Swal.fire({
								  icon: 'success',
								  text: res.message,
								  
								 }).then(function() {
								 	
								  
								    emp_data = $.parseJSON(res.data);
								    if(emp_data.EmployeeName){
								    	$("#applicant_name").val(emp_data.EmployeeName);
								    }
								    if(emp_data.WorkingDepartmentname && emp_data.WorkingDepartmentCode){
								    	empdpt_code = emp_data.WorkingDepartmentCode;
								    	emp_dept    = emp_data.WorkingDepartmentname;

								    	$("#department").val(emp_dept+' ('+empdpt_code+') ');
								    }
								    if(emp_data.WorkingDesignationName){
								    	$("#present_post").val(emp_data.WorkingDesignationName);
								    }
								    $("#payee_code_submit").hide();
									$(".employee_data").show();
								})



                     	}

				    }
				});

	})


/*-----------------------------------------------------
| Check Application For Validation
-------------------------------------------------------*/

	$("#submit_application").click(function(e){

		  e.preventDefault();

		  if(!$('#payee_code').val()){

			  	Swal.fire({
						  icon:  "error",
						  title: "Oops...",
						  text:  "Payee Code Can't  Be Blank",
						  
						});
			  	return false;
		  }
		  if(!$('#applicant_name').val()){

			  	Swal.fire({
						  icon:  "error",
						  title: "Oops...",
						  text:  "Applicant Name Can't  Be Blank",
						  
						});
			  	return false;
		  }
		  if(!$('#father_name').val()){

			  	Swal.fire({
						  icon:  "error",
						  title: "Oops...",
						  text:  "Father Name Can't  Be Blank",
						  
						});
			  	return false;
		  }
		  if(!$('#mother_name').val()){

			  	Swal.fire({
						  icon:  "error",
						  title: "Oops...",
						  text:  "Mother Name Can't  Be Blank",
						  
						});
			  	return false;
		  }
		  if(!$('#department').val()){

			  	Swal.fire({
						  icon:  "error",
						  title: "Oops...",
						  text:  "Department Name Can't  Be Blank",
						  
						});
			  	return false;
		  }
		  if(!$('#dob').val()){

			  	Swal.fire({
						  icon:  "error",
						  title: "Oops...",
						  text:  "Date Of Birth Can't  Be Blank",
						  
						});
			  	return false;
		  }
		  if(!$('#email').val()){

			  	Swal.fire({
						  icon:  "error",
						  title: "Oops...",
						  text:  "Email Can't  Be Blank",
						  
						});
			  	return false;
		  }
		  if(!$('#mobile').val()){

			  	Swal.fire({
						  icon:  "error",
						  title: "Oops...",
						  text:  "Mobile Can't  Be Blank",
						  
						});
			  	return false;
		  }
		  if(!$('#education').val()){

			  	Swal.fire({
						  icon:  "error",
						  title: "Oops...",
						  text:  "Education Qualification Can't Be Blank",
						  
						});
			  	return false;
		  }
		  if(!$('#category').val()){

			  	Swal.fire({
						  icon:  "error",
						  title: "Oops...",
						  text:  "Category Can't Be Blank",
						  
						});
			  	return false;
		  }

		  if(!$('#confirmation_date').val()){

			  	Swal.fire({
						  icon:  "error",
						  title: "Oops...",
						  text:  "Confirmation Date Can't Be Blank",
						  
						});
			  	return false;
		  }

		  if(!$('#present_post').val()){

			  	Swal.fire({
						  icon:  "error",
						  title: "Oops...",
						  text:  "Present Post Held Can't Be Blank",
						  
						});
			  	return false;
		  }

		  if(!$('#appointment_date').val()){

			  	Swal.fire({
						  icon:  "error",
						  title: "Oops...",
						  text:  "Appointment Date Can't Be Blank",
						  
						});
			  	return false;
		  }
		  if(!$('#post_name').val()){

			  	Swal.fire({
						  icon:  "error",
						  title: "Oops...",
						  text:  "Name Of Post Can't Be Blank",
						  
						});
			  	return false;
		  }
		  if( !$('.sel_post_hold').is(':checked') ){
		    	Swal.fire({
						  icon:  "error",
						  title: "Oops...",
						  text:  "Whether Holding That Post Substantively Can't Be Blank",
						  
						});
			  	return false;
		 }
		  if(!$('#correspondence_address').val()){

			  	Swal.fire({
						  icon:  "error",
						  title: "Oops...",
						  text:  "Correspondence Address Can't Be Blank",
						  
						});
			  	return false;
		  }
		  if(!$('#permanent_address').val()){

			  	Swal.fire({
						  icon:  "error",
						  title: "Oops...",
						  text:  "Permanent Address Can't Be Blank",
						  
						});
			  	return false;
		  }
		  if(!$('#applicant_photo').val()){

			  	Swal.fire({
						  icon:  "error",
						  title: "Oops...",
						  text:  "Upload Your Photo Can't Be Blank",
						  
						});
			  	return false;
		  }
		  if(!$('#applicant_signature').val()){

			  	Swal.fire({
						  icon:  "error",
						  title: "Oops...",
						  text:  "Upload Your Signature Can't Be Blank",
						  
						});
			  	return false;
		  }
		  if(!$('#acknowledge').is(':checked')){

			  	Swal.fire({
						  icon:  "error",
						  title: "Oops...",
						  text:  "Acknowledge Can't Be Blank",
						  
						});
			  	return false;
		  }
		  if(!$('#captcha').val()){

			  	Swal.fire({
						  icon:  "error",
						  title: "Oops...",
						  text:  "Captcha Can't Be Blank",
						  
						});
			  	return false;
		  }

		  

		  
		  


	});

})