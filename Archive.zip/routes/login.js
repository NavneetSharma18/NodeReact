const express                     = require('express');
const flash                       = require('connect-flash');
const { check, validationResult } = require('express-validator');
const passport                    = require('passport');
const session                     = require('express-session');
const captchapng                  = require('captchapng');
const saltRounds                  = 10;
const router                      = express.Router();
const User                        = require('../models/user');
var CryptoJS                      = require("crypto-js");
const {isGuest}                   = require('../auth/auth.js');
const Role                        = require('../models/role');

const {indexView,registerView, registerUser,logoutUser,validateLoginView,validateLogin,validatePayeeCode} = require('../controllers/loginController');



/*-------------------------------------------
| Generate Captcha
---------------------------------------------*/


router.get("/captcha.png", (req, res, next) => {
    
   if(req.url == '/captcha.png') {

        var captcha_code = parseInt(Math.random()*9000+1000);
        
        req.session.captcha_code = captcha_code;

        var p = new captchapng(80,30,captcha_code); // width,height,numeric captcha
        p.color(0, 0, 0, 0);  // First color: background (red, green, blue, alpha)
        p.color(80, 80, 80, 255); // Second color: paint (red, green, blue, alpha)
 
        var img = p.getBase64();
        var imgbase64 = new Buffer.from(img,'base64');

        res.writeHead(200, {
            'Content-Type': 'image/png'
        });

        res.end(imgbase64);

        
    } else {
        response = {  
                       status:false,  
                       image:''  
                   };  
                   
        res.end(JSON.stringify(response)); 
    }

});
 
/*-------------------------------------------
| Home Pages
---------------------------------------------*/
router.get('/', indexView);



/*--------------------------------------------
| Login functionality start from here
---------------------------------------------*/



router.get('/login', validateLoginView);

router.post("/validateLogin",[

    check('username', " Mobile can't be blank").isLength({ min: 10 }),
    check('captcha_code', 'captcha code can`t be blank ')

], validateLogin);




router.post("/login", (req, res, next) => {

      
      let enterOtp           = req.body.password;
      var key                = process.env.KEY;
      var decrypted_usr      = CryptoJS.AES.decrypt(req.body.verified_key1, key);
      var username           = decrypted_usr.toString(CryptoJS.enc.Utf8);
      req.body.username      = username;
      req.body.password      = enterOtp;

      passport.authenticate('local', {
        successRedirect: '/dashboard',
        failureRedirect: '/',
        failureFlash: true
      })(req, res, next);

});

router.get('/dashboard', (req, res) => {

  if (req.isAuthenticated()) {

             const user = req.user;

              //console.log(user);return false;
 
             if(user){

                 Role.findOne({_id:user.role_id}, function (err, role) {
                    
                    if (err){
                        console.log(err)
                        req.flash('error_msg',err);
                        res.redirect('/');

                    }

                    //console.log(role);return false;

                    if (role.role_name === 'admin') {

                        req.flash('error_msg','Login successfully to Admin dashbaord');
                        res.redirect('/admin/dashboard');

                    } else if (role.role_name === 'user') {

                        req.flash('error_msg','Login successfully to User dashbaord');
                        res.redirect('/user/dashboard');

                    }else{
                        req.flash('error_msg','Invalid login found..');
                        res.redirect('/'); 
                    }
  
                 });
             }

    } else {

       req.flash('error_msg','Invalid login found...');
       res.redirect('/'); 
    }

});





/*-----------------------------------------------------
| ****** Register Routes Start from here ******
-------------------------------------------------------*/

router.post('/validatePayeeCode', validatePayeeCode);
router.get('/register', registerView);
router.post('/register',[
    
    check('name', 'Name length should be 3 to 20 characters')
                    .isLength({ min: 3, max: 20 }),
    check('email', 'Email can`t be blank and should be valid email')
                    .isEmail(),
    check('confirm', 'Confirm length should be atleast 3  characters')
                    .isLength({ min: 3}),
    check('password', 'Password length should be atleast 3 characters')
                    .isLength({ min: 3 })
                    .custom((val, { req, loc, path }) => {
                                if (val !== req.body.confirm) {
                                    throw new Error("Passwords and confirm password don't match");
                                } else {
                                    return true;
                                }
                            })
],registerUser);


/*-----------------------------------------------------
| ****** Logout user ******
-------------------------------------------------------*/


router.post('/logout', 
  logoutUser
);



module.exports = router;