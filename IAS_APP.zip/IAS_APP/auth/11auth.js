const flash = require('connect-flash');
const Role  = require('../models/role');

const isAuthenticated = (req,res,done)=>{

	Role.findOne({role_name:'admin'}, function (err, role) {

        if(err){
        	req.flash('error_msg',err);
            return res.redirect('/');
        }
       
       if(req.user && req.user.role_id.equals(role._id) ){
		  return done()
	   }else{
	   	return res.redirect("/");
	   }
	   

	});

	
	
}

module.exports =  {
    isAuthenticated,
};