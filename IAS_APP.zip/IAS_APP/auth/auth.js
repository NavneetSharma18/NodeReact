const flash = require('connect-flash');
const Role  = require('../models/role');


const isAdmin = (req,res,done)=>{

	Role.findOne({role_name:'admin'}, function (err, role) {

        if(err){
        	req.flash('error_msg',err);
            return res.redirect('/');
        }
       
       if(req.user && req.user.role_id.equals(role._id) ){
		  return done()
	   }else{
	   	return res.redirect("/");
	   }
	   

	});

	
	
}

const isUser = (req,res,done)=>{

	Role.findOne({role_name:'user'}, function (err, role) {

        if(err){
        	req.flash('error_msg',err);
            return res.redirect('/');
        }
       
       if(req.user && req.user.role_id.equals(role._id) ){
		  return done()
	   }else{
	   	return res.redirect("/");
	   }
	   

	});
}

const isGuest = (req,res,done)=>{


        if (!req.session.user) {
	     return done()
	  } else{
	  	return res.redirect("/");
	  }
	   

}


module.exports =  {
    isAdmin,
    isUser,
    isGuest
};