const bcrypt                      = require('bcrypt');
const saltRounds                  = 10;
const md5                         = require('md5');
const passport                    = require('passport');
const LocalStrategy               = require('passport-local').Strategy;
const User                        = require('../models/user');
const session                     = require('express-session');

module.exports = function(passport) {

    passport.use(new LocalStrategy(

      function(username, password, done) {
          

        if(!username || !password){  return done(null, false, {message: "username and OTP can't be blank" }); }
        
         User.findOne({ mobile: username }, function (err, user) {

              //console.log(user);return false;

              if (err) { return done(null,false,{ message: err }) }

              if (!user) { return done(null, false,{ message: 'That mobile is not registered with us' }); }
            
              if ( user.password != password ) {return done(null, false,{ message: 'Incorrect OTP' });  }

              return done(null, user);

        });
      }
      
    ));


    passport.serializeUser((user,done) =>{
        // session store only user id so that rest ino of user is ignored due to wastage of memory
        if(user){
            return done(null,user.id)
        }
        return done(null,false)

    });

    passport.deserializeUser((id,done) =>{

        User.findById(id,(err,user)=>{
            if(err)  return done(null,false);
            return done(null,user)

        })
        
    })

}
