const { check, validationResult } = require('express-validator');
const bcrypt                      = require('bcrypt');
const saltRounds                  = 10;
const passport                    = require('passport');
const LocalStrategy               = require('passport-local');
const flash                       = require('connect-flash');
var CryptoJS                      = require("crypto-js");
const md5                         = require('md5');
const User                        = require('../models/user');
const Role                        = require('../models/role');




/*-------------------------------------------------------
| Load register view 
---------------------------------------------------------*/


const indexView = (req, res) => {

        res.render("index",{req});
}



/*-------------------------------------------------------
| Load register view 
---------------------------------------------------------*/


const registerView = (req, res) => {

        res.render("register");
}



/*-------------------------------------------------------
| Validate Login view 
---------------------------------------------------------*/


const validateLoginView = (req, res) => {
        //console.log(req);return false;
        res.render("login", {req} );
}


/*-------------------------------------------------------
| Load Login view 
---------------------------------------------------------*/


const validateLogin = (req, res) => {


        let       roleId        = [];
        const     userReq       = req.body;
        const     validError    = validationResult(req);
        const     errors        = validError.array();
        var       username      = userReq.username;
        var       cpathca_code  = userReq.captcha;
        var       key           = process.env.KEY;
        
        var decrypted_usr       = CryptoJS.AES.decrypt(username, key);
        var username            = decrypted_usr.toString(CryptoJS.enc.Utf8);



        var decrypted_cap       = CryptoJS.AES.decrypt(cpathca_code, key);
        var captcha             = decrypted_cap.toString(CryptoJS.enc.Utf8);

    
        if (errors.length > 0) {
           res.json({"status":false,"message":errors});  

        }else if(captcha!= req.session.captcha_code){
            res.json({"status":false,"message":'Incorrect captcha code'}); 

        }else {

                // Send OTP FROM Here

                let OTPCODE    = '111111'
               
                User.findOne({ mobile: username }, function (err, user) {

                      if (err) { 
                         res.json({"status":false,"message":err}); 
                      }

                      if (!user) { 
                           res.json({"status":false,"message":'That mobile is not registered with us'}); 
                       }else{

                                // update user password with OTP

                                user.password     = OTPCODE;
                                user.save();

                                req.session.sess_otp    = OTPCODE;
                                req.session.sess_mobile = user.mobile;

                                var usermobile       = CryptoJS.AES.encrypt(user.mobile, key);
                                var userOtp          = CryptoJS.AES.encrypt(OTPCODE ,key);
                                res.json({"status":true,"message":"mobile validated successfully & OTP sent to your mobile number!","mobile":''+usermobile+'', "OTP":''+userOtp+''}); 
                                 
                       }

                      
                });

                
            }

            
                
  
}



/*-------------------------------------------------------
| Post register request 
---------------------------------------------------------*/


const registerUser = (req, res) =>{

        
        const validError  = validationResult(req);
        const errors      = validError.array();

        
        if (errors.length > 0) {    
            console.log(errors);
            res.render('register',{
                errors
            });
        }
        else {
                const errors        = [];
                let roleId          = [];
                const userReq       = req.body;
                const insertUser    = new User(userReq);

                Role.findOne({role_name:'user'}, function (err, role) {
                        if (err){
                            console.log(err)
                            req.flash('error_msg',err);
                            res.redirect('register');

                        }
                    
                        insertUser.password = md5(md5(userReq.password));
                        insertUser.role_id  = role._id;

                        User.findOne({email:userReq.email}, function (err, user) {

                            if (err){
                                req.flash('error_msg',err);
                                res.redirect('register');

                            }

                            if(user){
                                req.flash('error_msg','User already exist with this email try with another email');
                                res.redirect('register');

                            }else{

                                    insertUser.save().then(data => {

                                      req.flash('success_msg','You are now registered and can log in');
                                      res.redirect('register');

                                    }).catch( err =>{
                                            console.log(err)
                                            errors.push(err);

                                            res.render('register',{
                                              errors
                                            });
                                        
                                    });

                            }
                        });

                 });

               
        }
   
}


/*---------------------------------------------------------
| Redirect user to their dahsboard based on role
---------------------------------------------------------*/




/*------------------------------------------------------
| Logout user
-------------------------------------------------------*/

const logoutUser = (req,res,next) =>{
    req.logout(function(err) {
    if (err) { return next(err); }
    res.redirect('/');
   });
}




/*-------------------------------------------------------
| Export model
---------------------------------------------------------*/




module.exports =  {
    indexView,
    registerView,
    registerUser,
    logoutUser,
    validateLoginView,
    validateLogin,
};