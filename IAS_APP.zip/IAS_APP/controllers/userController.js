const {PROJECT_DIR}               = require('../setting.js');
const flash                       = require('connect-flash');
const User                        = require('../models/user');
const Role                        = require('../models/role');
const md5                         = require('md5');
const XLSX                        = require('xlsx');
const { v4: uuidv4}               = require('uuid');



/*--------------------------------------------
| Render admin dashboard view
---------------------------------------------*/


const dashboardView = (req, res) => {
    const user = req.user;
    res.render("./user/dashboard", {
    	user    
    } );
}

/*--------------------------------------------
| Render File upload view
---------------------------------------------*/

const uploadView = (req, res) => {

    const user = req.user;
    res.render("upload_image",{user,req});
}

/*--------------------------------------------
|  File upload functionality
---------------------------------------------*/

const uploadPost = (req, res) => {
         
	     if (!req.files){
	     	    
	     		req.flash('error_msg','Please select file');
	            res.redirect('/admin/upload');

	      }else if(req.files.uploadfile.mimetype != 'image/jpeg'){

	      	    req.flash('error_msg','Only jpeg file allowed');
	            res.redirect('/admin/upload');

	      }else{

	      	     sampleFile = req.files.uploadfile;
			     uploadPath = PROJECT_DIR+'/uploads/'+Date.now()+sampleFile.name;

			     sampleFile.mv(uploadPath, function(err) {

				     if (err){

				     	req.flash('error_msg',err);
		                res.redirect('/admin/upload');
		             
				     }else{

				     	req.flash('success_msg','File uploaded successfully!');
		                res.redirect('/admin/upload');
		                
				     }
			      
			     });
        	  
			}
    
}


/*--------------------------------------------
| Render Manage users view
---------------------------------------------*/

const manageusersView = (req, res) => {

    const user = req.user;


    		Role.findOne({role_name:'user'}, function (err, role) {

		        if(err){
		        	req.flash('error_msg',err);
		            return res.redirect('/admin/manageusers');
		        }

		        User.find({role_id:role._id},function (err, allUsers) {

                    if (err){
                        req.flash('error_msg',err);
                        res.redirect('register');

                    }
                    console.log(allUsers);
                    res.render("./admin/manageusers",{user,req,allUsers});
                    
                }).populate("role_id");

		    });
		        

   
}

/*--------------------------------------------
| Edit users view
---------------------------------------------*/

const edituserView = (req, res) => {

         const user    = req.user;
         const user_id = req.query.key
   
    		

          User.findOne({_id:user_id}, function (err, getUser) {

            if(err){
        	   req.flash('error_msg',err);
               return res.redirect('/admin/manageusers');
             }
           

            res.render("./admin/updateuser",{user,req,getUser});
            
          }).populate("role_id");
  
}

/*--------------------------------------------
| Update users view
---------------------------------------------*/
const updateUser = async(req, res) => {

	     
         const user_id = req.body.key;

	     if(!user_id){

	     	req.flash('error_msg',"User doesn't exist");
	        res.redirect('/admin/manageusers');

	     }else if (!req.body.name){
	     	    
	     		req.flash('error_msg',"User name can't be blank");
	            res.redirect('/admin/edituser?key='+user_id);

	      }else if(!req.body.email){

	      	    req.flash('error_msg','Only jpeg file allowed');
	            res.redirect('/admin/edituser?key='+user_id);

	      }else{
					const filter = { _id: user_id };
					const update = { name: req.body.name, email: req.body.email};
					const doc    = await User.findOneAndUpdate(filter, update, {
					  new: true
					});

				    req.flash('success_msg','User updated successfully');
	                res.redirect('/admin/edituser?key='+user_id);
			}
    
}


/*--------------------------------------------
| Add New User
---------------------------------------------*/

const addnewuserView = (req, res) => {

    const user = req.user;
    res.render("./admin/add_new_user",{user,req});
}

/*--------------------------------------------
| Add New User Post 
---------------------------------------------*/

const adduserView = async(req, res) => {

	     
         const post = req.body;
         console.log(post);

	      if (!post.name){
	     	    
	     		req.flash('error_msg',"User name can't be blank");
	            res.redirect('/admin/addnewuser');

	      }else if(!post.email){

	      	    req.flash('error_msg','Only jpeg file allowed');
	            res.redirect('/admin/edituser?key=');

	      }else if(!post.password){

	      	    req.flash('error_msg',"Password can't be blank");
	            res.redirect('/admin/addnewuser');

	      }else if(!post.confirm_password){

	      	    req.flash('error_msg',"Confirm Password can't be blank");
	            res.redirect('/admin/addnewuser');

	      }else if(post.password !== post.confirm_password){

	      	    req.flash('error_msg',"Password and confirm password  doesn't matched");
	            res.redirect('/admin/addnewuser');

	      }else{
				  User.findOne({email:post.email}).then((user) => {

				  if (user){
				  	   req.flash('error_msg','Email already taken by other user try with different email');
	                   res.redirect('/admin/addnewuser');
				  }else{

				  		Role.findOne({role_name:'user'}, function (err, role) {

					        if(err){
					        	req.flash('error_msg',err);
					            return res.redirect('/admin/addnewuser');
					        }else{

					        	passowrd            = md5(md5(post.password));
					        	insertUser          = new User();

					        	insertUser.name     = post.name;
					        	insertUser.email    = post.email;
					        	insertUser.password = passowrd;
					        	insertUser.role_id  = role._id;

					        	insertUser.save().then(data => {

                                      req.flash('success_msg','You are now registered and can log in');
                                      res.redirect('/admin/addnewuser');

                                }).catch( err =>{
                                    req.flash('error_msg',err);
                                    res.redirect('/admin/addnewuser');
                                });

				  		     
					        }

					    });
				  		


				  } 
				  
				 }).catch((err) => {
				     req.flash('error_msg',err.stringify());
	                 res.redirect('/admin/addnewuser');
				 })

				    
			}
    
}



/*--------------------------------------------
| Upload User
---------------------------------------------*/

const uploaduserExcel = (req, res) => {

    const user = req.user;
    res.render("./admin/upload_user",{user,req});
}



const uploaduserPost = async(req, res) => {

		 console.log(req.files);

	     if (!req.files){
	     	    
	     		req.flash('error_msg','Please upload file');
	            res.redirect('/admin/uploaduser');

	      }else if(req.files.upload_file.size > '1059381' ){

	      	    req.flash('error_msg','Only 1 MB file allowed');
	            res.redirect('/admin/uploaduser');

	      }else if(req.files.upload_file.mimetype != 'application/vnd.ms-excel' && req.files.upload_file.mimetype !=  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'){

	      	    req.flash('error_msg','Only xsl file allowed');
	            res.redirect('/admin/uploaduser');

	      }else{


					
		      	     sampleFile = req.files.upload_file;
				     uploadPath = PROJECT_DIR+'/uploads/'+Date.now()+sampleFile.name;

				     sampleFile.mv(uploadPath, function(err) {

					     if (err){

					     	req.flash('error_msg',err);
			                res.redirect('/admin/uploaduser');
			             
					     }else{

					     	var workbook        = XLSX.readFile(uploadPath);
							var sheet_name_list = workbook.SheetNames;
							var xlData          = XLSX.utils.sheet_to_json(workbook.Sheets[sheet_name_list[0]]);
							
							Role.findOne({role_name:'user'}, function (err, role) {

						        if(err){
						        	req.flash('error_msg',err);
						            return res.redirect('/admin/uploaduser');
						        }else{

						        	var totalRec = 0;
						        	xlData.forEach(val => {

									    pass_user           = val.password;

									    //console.log(md5(md5(pass_user)));
							        	userModel           = new User();

							        	userModel.name      = val.name;
							        	userModel.email     = val.email;
							        	userModel.password  = md5(md5(pass_user));
							        	userModel.role_id   = role._id;

							        	userModel.save().then(data => {   
							        		console.log(data)
		                                }).catch( err =>{
		                                	console.log(err)
		                                   // req.flash('error_msg',err);
		                                   // res.redirect('/admin/uploaduser');
		                                });

		                                totalRec = totalRec+1;

									});

									req.flash('success_msg','Total user created is '+totalRec);
		                            res.redirect('/admin/uploaduser');
					  		     
						        }

						    });

			                
					     }
				      
				     });
        	  
			}
}


/*--------------------------------------------
| Create Video Call View
---------------------------------------------*/

const loadVCV = (req, res) => {

	//res.redirect(`/user/loadVCV/${uuidv4()}`);
    const user = req.user;
    res.render("./user/video_call",{roomId: req.param.room ,user:user});
}





module.exports =  {
    dashboardView,
    uploadView,
    uploadPost,
    manageusersView,
    edituserView,
    updateUser,
    addnewuserView,
    adduserView,
    uploaduserExcel,
    uploaduserPost,
    loadVCV,
    
};