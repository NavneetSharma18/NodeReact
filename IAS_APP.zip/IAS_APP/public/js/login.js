$(document).ready(function(){


	
  /*------------------------------------
  | Login Button Click
  -------------------------------------*/

		$("#login_Button").click(function(){


				if(!$("#username").val()){
						Swal.fire({
						  icon: 'error',
						  title: 'Oops...',
						  text: 'username can`t be empty',
						  
						})
						return false;
				}

				if(!$("#captcha").val()){
						Swal.fire({
						  icon: 'error',
						  title: 'Oops...',
						  text: 'Captcha can`t be empty',
						  
						})
						return false;
				}


				var username    = $("#username").val();
				var captcha     = $("#captcha").val();

	            username        = CryptoJS.AES.encrypt(username, Skey);
	            captcha         = CryptoJS.AES.encrypt(captcha, Skey);
			   
			   $("#loading").show();
				$.ajax({
					
					 method  : "post",
					 url     : "/validateLogin", 
					 data    : {"username":''+username+'',"captcha":''+captcha+''} ,
					 dataType: "json",
                     success: function(res){

                     	$("#loading").hide();

                     	if(res.status == false){
                     		  Swal.fire({
								  icon: 'error',
								  title: 'Oops...',
								  text: res.message,
								  
								}).then(function() {
								    location.reload();
								})
								return false;
                     	}else{

                     			 $("#username").attr('readonly',true);
                     			 $("#verified_key1").val(res.mobile);
                     			 $("#verified_key2").val(res.OTP);

                     		     Swal.fire({
								  icon: 'success',
								  text: res.message,
								  
								 })

                     		     $("#captcha_div, #login_Button").hide();
                     		     $("#enter_otp_div, #submit_button").show();


                     	}

				    }
				});
				
				


		 })

	/*-----------------------------------------------
	|************ END *********************
	------------------------------------------------*/


    /*------------------------------------
    | Submit OTP And Login User
    -------------------------------------*/

		 $(document).on("click","#submit_button",function(){

		 	   if(!$("#mobile_pin").val()){
						Swal.fire({
						  icon: 'error',
						  title: 'Oops...',
						  text: 'OTP can`t be empty',
						  
						})
						return false;
				}

				var enter_otp           = $("#mobile_pin").val();
				var user_validate_key1  = $("#verified_key1").val();
				var user_validate_key2  = $("#verified_key2").val();

				$("#loading").show();
				$("#login_form").attr('action','/login');
				$("#login_form").submit();



				// $.ajax({
					
				// 	 method  : "post",
				// 	 url     : "/login", 
				// 	 data    : {"username":user_validate_key1,"password":''+enter_otp+''} ,
				// 	 dataType: "json",
                //      success: function(res){

                //      	if(res.status == false){
                //      		Swal.fire({
				// 				  icon: 'error',
				// 				  title: 'Oops...',
				// 				  text: res.message,
								  
				// 				})
				// 				return false;
                //      	}else{

                //      			 $("#username").attr('readonly',true);
                //      			 $("#verified_key1").val(res.mobile);
                //      			 $("#verified_key2").val(res.OTP);

                //      		     Swal.fire({
				// 				  icon: 'success',
				// 				  text: res.message,
								  
				// 				 });

                //      		     $("#captcha_div, #login_Button").hide();
                //      		     $("#enter_otp_div, #submit_button").show();


                //      	}

				//     }
				// });



		 })
		

		

});