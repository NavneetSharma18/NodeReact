$(document).ready(function(){
	
	$("#payee_code_submit").click(function(){

	         if(!$("#payee_code").val()){
			    Swal.fire({
				  icon: 'error',
				  title: 'Oops...',
				  text: 'Payee code can`t be empty',
				  
				})
				return false;
	         }

	           const payee_code = $("#payee_code").val();
	            payee_code      = CryptoJS.AES.encrypt(payee_code, Skey);

			   $("#loading").show();
				$.ajax({
					
					 method  : "post",
					 url     : "/validatePayeeCode", 
					 data    : {"payee_code":''+payee_code+''} ,
					 dataType: "json",
                     success: function(res){

                     	$("#loading").hide();

                     	if(res.status == false){
                     		  Swal.fire({
								  icon: 'error',
								  title: 'Oops...',
								  text: res.message,
								  
								}).then(function() {
								    location.reload();
								})
								return false;
                     	}else{

                     			 $("#username").attr('readonly',true);
                     			 $("#verified_key1").val(res.mobile);
                     			 $("#verified_key2").val(res.OTP);

                     		     Swal.fire({
								  icon: 'success',
								  text: res.message,
								  
								 })

                     		     $("#captcha_div, #login_Button").hide();
                     		     $("#enter_otp_div, #submit_button").show();


                     	}

				    }
				});

	})

})