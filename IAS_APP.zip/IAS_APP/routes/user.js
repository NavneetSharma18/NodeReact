const express                                = require('express');
const flash                                  = require('connect-flash');
const fileUpload                             = require('express-fileupload');
const { check, validationResult }            = require('express-validator');
const {dashboardView,uploadView,uploadPost,manageusersView,edituserView,updateUser,addnewuserView,adduserView,uploaduserExcel,uploaduserPost,loadVCV} = require('../controllers/userController');
const router                                 = express.Router();


/*--------------------------------------------
| Admin dashboard routes
---------------------------------------------*/

router.get('/dashboard', dashboardView);
router.get('/:loadVCV', loadVCV);




// router.use(fileUpload({
//   limits: { fileSize: 50 * 1024 * 1024 },
// }));

// router.get('/upload', uploadView);
// router.post('/upload', uploadPost);

// /*----------------------------------
// | Manage Users
// -----------------------------------*/

// router.get('/manageusers', manageusersView);
// router.get('/edituser', edituserView);
// router.post('/updateuser', updateUser);


// /*----------------------------------
// | Add New User
// -----------------------------------*/

// router.get('/addnewuser', addnewuserView);
// router.post('/addnewuser', adduserView);


// /*----------------------------------
// | Upload User
// -----------------------------------*/

// router.get('/uploaduser', uploaduserExcel);
// router.post('/uploaduser', uploaduserPost);




module.exports = router;